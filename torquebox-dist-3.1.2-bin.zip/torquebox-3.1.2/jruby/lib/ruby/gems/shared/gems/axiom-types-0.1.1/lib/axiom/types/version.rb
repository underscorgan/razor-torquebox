# encoding: utf-8

module Axiom
  module Types

    # Gem version
    VERSION = '0.1.1'.freeze

  end # module Types
end # module Axiom
