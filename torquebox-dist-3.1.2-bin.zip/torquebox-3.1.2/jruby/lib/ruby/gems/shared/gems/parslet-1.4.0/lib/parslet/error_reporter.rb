# A namespace for all error reporters.
#
module Parslet::ErrorReporter
end

require 'parslet/error_reporter/tree'
require 'parslet/error_reporter/deepest'