require 'maven'
module Maven
  module Ruby
    MAVEN_VERSION = ::Maven::VERSION
    VERSION = MAVEN_VERSION + '.0.8'# + '.dev'
  end
end
