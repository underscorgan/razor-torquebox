# encoding: utf-8

class Equalizer < Module

  # Gem version
  VERSION = '0.0.9'.freeze

end # class Equalizer
