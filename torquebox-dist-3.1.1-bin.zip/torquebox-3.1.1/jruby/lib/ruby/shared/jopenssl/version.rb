module Jopenssl
  module Version
    VERSION = "0.9.5"
    BOUNCY_CASTLE_VERSION = "1.47"
  end
end
