module Krypt
  module Provider
    module Jdk
      VERSION = '0.0.2'
    end
  end
end
