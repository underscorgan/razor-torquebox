module Krypt
  module Core
    VERSION = '0.0.2'
  end
end
