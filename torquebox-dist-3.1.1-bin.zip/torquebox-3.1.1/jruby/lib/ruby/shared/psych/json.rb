module Psych
  module JSON
    autoload :TreeBuilder, 'psych/json/tree_builder'
    autoload :Stream, 'psych/json/stream'
  end
end
