To compile the nailgun client, type './configure' and 'make' in this directory.

Windows binary is distributed with JRuby.

Documentation is under development.  For up-to-date information,
including a "Quick Start" guide, visit:

	http://www.martiansoftware.com/nailgun
	
Javadocs for NailGun are in the "docs/api" directory with the
source distribution, and are also available at the above website.
