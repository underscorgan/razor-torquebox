module Krypt
  module Core
    class Version
      VERSION = "0.1.0.dev"
    end
  end
end

