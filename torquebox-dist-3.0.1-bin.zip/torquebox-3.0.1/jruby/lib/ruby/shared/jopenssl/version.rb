module Jopenssl
  module Version
    VERSION = "0.9.4"
  end
end
