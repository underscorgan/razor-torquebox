<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr">

<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript">var NREUMQ=NREUMQ||[];NREUMQ.push(["mark","firstbyte",new Date().getTime()]);</script><link rel="shortcut icon" href="http://opensource.org/files/garland_favicon.png" type="image/png" />
<link rel="shortlink" href="/node/66" />
<link rel="canonical" href="/licenses/MIT" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
  <title>The MIT License (MIT) | Open Source Initiative</title>
  <link type="text/css" rel="stylesheet" href="http://opensource.org/files/css/css_pbm0lsQQJ7A7WCCIMgxLho6mI_kBNgznNUWmTWcnfoE.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://opensource.org/files/css/css_SUL4nLPHzR3nTjXtabIi37KnqgcaT9eAQRNBvMXWGXs.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://opensource.org/files/css/css_2wI77kyP-rJKVpFW5M3KFcj7Cb99lZalmubKIwWwsmU.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://opensource.org/files/css/css_k3snrbsthqot7V7ccRZHS9OkCZkwBv4adtNieIVlbEU.css" media="print" />

<!--[if lt IE 7]>
<link type="text/css" rel="stylesheet" href="http://opensource.org/themes/garland/fix-ie.css?n291is" media="all" />
<![endif]-->
  <script type="text/javascript" src="http://opensource.org/files/js/js_xAPl0qIk9eowy_iS9tNkCWXLUVoat94SQT48UBCFkyQ.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"garland","theme_token":"RBLir3ZGz1PRdmcDq8gV3-NPqk7rKTiGGVeOAS4Gl44","js":{"misc\/jquery.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"modules\/aggregator\/aggregator.css":1,"modules\/comment\/comment.css":1,"modules\/field\/theme\/field.css":1,"sites\/all\/modules\/mollom\/mollom.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"themes\/garland\/style.css":1,"themes\/garland\/print.css":1,"themes\/garland\/fix-ie.css":1}}});
//--><!]]>
</script>
</head>
<body class="html not-front not-logged-in one-sidebar sidebar-first page-node page-node- page-node-66 node-type-page fluid-width" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
      
  <div id="wrapper">
    <div id="container" class="clearfix">

      <div id="header">
        <div id="logo-floater">
                              <div id="branding"><strong><a href="/">
                          <img src="http://opensource.org/files/garland_logo.png" alt="Open Source Initiative " title="Open Source Initiative " id="logo" />
                        <span>Open Source Initiative</span>            </a></strong></div>
                          </div>

                      </div> <!-- /#header -->

              <div id="sidebar-first" class="sidebar">
            <div class="region region-sidebar-first">
    <div id="block-search-form" class="block block-search clearfix">

    <h2 class="title">Search this site:</h2>
  
  <div class="content">
    <form action="/licenses/mit-license.php" method="post" id="search-block-form" accept-charset="UTF-8"><div><div class="container-inline">
    <div class="form-item form-type-textfield form-item-search-block-form">
  <label class="element-invisible" for="edit-search-block-form--2">Search </label>
 <input title="Enter the terms you wish to search for." type="text" id="edit-search-block-form--2" name="search_block_form" value="" size="15" maxlength="128" class="form-text" />
</div>
<div class="form-actions form-wrapper" id="edit-actions"><input type="submit" id="edit-submit" name="op" value="Search" class="form-submit" /></div><input type="hidden" name="form_build_id" value="form-JGWxTNuDswn77gRaQ6oS8D6rmlVnnn6Ktv8IG3B0F_g" />
<input type="hidden" name="form_id" value="search_block_form" />
</div>
</div></form>  </div>
</div>
<div id="block-system-navigation" class="block block-system block-menu clearfix">

    <h2 class="title">Navigation</h2>
  
  <div class="content">
    <ul class="menu"><li class="first collapsed"><a href="/about" title="About the Open Source Initiative">About the OSI</a></li>
<li class="collapsed"><a href="/osd" title="The actual OSD defining what constitutes an Open Source licence">The Open Source Definition</a></li>
<li class="collapsed"><a href="/licenses">Open Source Licenses</a></li>
<li class="leaf"><a href="/working_groups">Working Groups</a></li>
<li class="leaf"><a href="/faq" title="Frequently Asked Questions about open source and about the OSI.">FAQ</a></li>
<li class="collapsed"><a href="/trademark" title="Information about trademark and logo usage">Trademark and Logo Usage</a></li>
<li class="collapsed"><a href="/osr-intro" title="Open Standards Requirement for Software">Open Standards</a></li>
<li class="leaf"><a href="/osi-open-source-education" title="OSI&#039;s Open Source Education Initiative and Activities">Open Source Education</a></li>
<li class="collapsed"><a href="/lists" title="The virtual committees where the OSI&#039;s work gets done">Mailing lists</a></li>
<li class="collapsed"><a href="/help" title="Resources for questions and further exploration">Getting Help</a></li>
<li class="collapsed"><a href="http://opensource.org/donate" title="">Donate to the OSI</a></li>
<li class="leaf"><a href="/members">OSI Individual Membership</a></li>
<li class="collapsed"><a href="/affiliates" title="Home page for OSI&#039;s membership scheme for non-profits and not-for-profits">OSI Affiliate Membership</a></li>
<li class="leaf"><a href="/contact" title="">Contact OSI</a></li>
<li class="leaf"><a href="/ToS" title="Rules for posting content on this site">Terms of Service</a></li>
<li class="last leaf"><a href="/sponsors">OSI Corporate Sponsors</a></li>
</ul>  </div>
</div>
  </div>
        </div>
      
      <div id="center"><div id="squeeze"><div class="right-corner"><div class="left-corner">
          <h2 class="element-invisible">You are here</h2><div class="breadcrumb"><a href="/">Home</a></div>                    <a id="main-content"></a>
          <div id="tabs-wrapper" class="clearfix">                                <h1 class="with-tabs">The MIT License (MIT)</h1>
                              </div>                                                  <div class="clearfix">
              <div class="region region-content">
    <div id="block-system-main" class="block block-system clearfix">

    
  <div class="content">
    <div id="node-66" class="node node-page">

  
      
  
  <div class="content clearfix">
        <img style="float: right; margin: 1em;" width="100" height="137" alt="[OSI Approved License]" src="/trademarks/opensource/OSI-Appro
ved-License-100x137.png"/>
        <div class="field field-name-body field-type-text-with-summary field-label-hidden"><div class="field-items"><div class="field-item even"><p>The MIT License (MIT)</p>
<p>Copyright (c) &lt;year&gt; &lt;copyright holders&gt;</p>
<p>Permission is hereby granted, free of charge, to any person obtaining a copy<br />
of this software and associated documentation files (the "Software"), to deal<br />
in the Software without restriction, including without limitation the rights<br />
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell<br />
copies of the Software, and to permit persons to whom the Software is<br />
furnished to do so, subject to the following conditions:</p>
<p>The above copyright notice and this permission notice shall be included in<br />
all copies or substantial portions of the Software.</p>
<p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR<br />
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,<br />
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE<br />
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER<br />
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,<br />
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN<br />
THE SOFTWARE.</p>
</div></div></div>  </div>

  <div class="clearfix">
          <div class="links"></div>
    
      </div>

</div>
  </div>
</div>
  </div>
          </div>
                      <div class="region region-footer">
    <div id="block-block-11" class="block block-block clearfix">

    
  <div class="content">
    <p style="text-align:center">Help shape the future of the Open Source Initiative...<br /><a href="http://osi.xwiki.com">visit and participate in the OSI wiki</a>.
</p>

<p>
<!-- Creative Commons License --><a rel="license" href="http://creativecommons.org/licenses/by/3.0/"><img alt="Creative Commons License" style="border-width: 0" src="http://i.creativecommons.org/l/by/3.0/88x31.png" /></a><br />Opensource.org site content is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution 3.0  License</a>.<!-- /Creative Commons License -->

<!-- <rdf:RDF xmlns="http://web.resource.org/cc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#">
	<Work rdf:about="">
		<license rdf:resource="http://creativecommons.org/licenses/by/3.0/" />
	</Work>
	<License rdf:about="http://creativecommons.org/licenses/by/3.0/"><permits rdf:resource="http://web.resource.org/cc/Reproduction"/><permits rdf:resource="http://web.resource.org/cc/Distribution"/><requires rdf:resource="http://web.resource.org/cc/Notice"/><requires rdf:resource="http://web.resource.org/cc/Attribution"/><permits rdf:resource="http://web.resource.org/cc/DerivativeWorks"/></License></rdf:RDF>
-->

| <a href="../ToS">Terms of Service</a>

</p>
  </div>
</div>
<div id="block-block-7" class="block block-block clearfix">

    
  <div class="content">
    <script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
<!--//--><![CDATA[// ><!--


//--><!]]>
</script><script type="text/javascript">
<!--//--><![CDATA[// ><!--

_uacct = "UA-3916956-1";
urchinTracker();

//--><!]]>
</script>  </div>
</div>
  </div>
      </div></div></div></div> <!-- /.left-corner, /.right-corner, /#squeeze, /#center -->

      
    </div> <!-- /#container -->
  </div> <!-- /#wrapper -->
  <script type="text/javascript">if(!NREUMQ.f){NREUMQ.f=function(){NREUMQ.push(["load",new Date().getTime()]);var e=document.createElement("script");e.type="text/javascript";e.src=(("http:"===document.location.protocol)?"http:":"https:")+"//"+"js-agent.newrelic.com/nr-100.js";document.body.appendChild(e);if(NREUMQ.a)NREUMQ.a();};NREUMQ.a=window.onload;window.onload=NREUMQ.f;};NREUMQ.push(["nrfj","beacon-1.newrelic.com","53c69192ac","224050","b1dRZkQCXEEHAEVRXFYdZkBfTFtcAgZJFkNQQg==",0,28,new Date().getTime(),"","","","",""]);</script></body>
</html>
